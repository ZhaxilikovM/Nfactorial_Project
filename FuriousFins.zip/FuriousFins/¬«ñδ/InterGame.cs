using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using static UnityEngine.Networking.UnityWebRequest;

public class InterGame : MonoBehaviour
{
    public static float speedgame = 2;
    private Renderer rr;
    public static bool isLife = true;
    void Start()
    {
        rr = GetComponent<Renderer>();
        speedgame = 2;
    }

    void Update()
    {
        speedgame += Time.deltaTime/10;
        Debug.Log(speedgame);
        if(!isLife)
        {
            isLife= true;
            DefeatGame();

        }
        if(Input.GetKeyDown(KeyCode.Return))
        {
            Time.timeScale = 1;
            SceneManager.LoadScene("menu");
        }
    }
    void DefeatGame()
    {
        rr.enabled = true;
        GetComponent<AudioSource>().Play();
        PlayerPrefs.SetInt("Result", CounterPoints.points);
        PlayerPrefs.Save();
        Time.timeScale = 0;
    }
    
}
