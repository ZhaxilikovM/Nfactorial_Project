using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BombScripts : MonoBehaviour
{
    private int rotateSpeed = 10;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Random.Range(1,5)==5)rotateSpeed+= Random.Range(-3,3);
        transform.Rotate(0, 0, rotateSpeed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.name == "Player")
        {
            InterGame.isLife = false;
            Destroy(gameObject);
        }
    }
}
