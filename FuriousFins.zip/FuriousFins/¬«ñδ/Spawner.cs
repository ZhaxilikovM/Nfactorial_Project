using UnityEngine;
using System;

public class Spawner : MonoBehaviour
{
    public GameObject bombPrefab;
    private AudioSource au;
    GameObject[] gameObjects = new GameObject[5];
    bool canPlus = true;
    private void Start()
    {
        au = GetComponent<AudioSource>();
        for(int i = 1; i < 5; i++)
        {
            gameObjects[i] = Instantiate(bombPrefab, new Vector3(transform.position.x, -3.5f + i, 1), Quaternion.identity);
        }
        gameObjects[0] = gameObject;
        SpawnOnRandamPlace();
    }
    private void Update()
    {
        if (canPlus && transform.position.x < 0)
        {
            canPlus = false;
            CounterPoints.points++;
            au.Play();
        }
        for (int i = 0; i < 5; i++)
        {
            try
            {
                gameObjects[i].transform.localPosition = (gameObjects[i].transform.localPosition + Vector3.left * Time.deltaTime * InterGame.speedgame);
            }catch(Exception e)
            {
            }
        }
        if (gameObjects[0].transform.position.x < -13.73f)
        {
            for (int i = 0; i < 5; i++)
            {
                try
                {
                    gameObjects[i].transform.position = new Vector3(9.55f, 3.55f, 0);
                    canPlus = true;
                }catch(Exception e)
                {
                }
            }
            SpawnOnRandamPlace();
        } 
    }

    void SpawnOnRandamPlace()
    {
        int x = UnityEngine.Random.Range(1,5);
        for (int i = 0; i < 5; i++)
        {
            if(i<x)
            gameObjects[i].transform.position = new Vector3(transform.position.x, -3.5f+i, 0);
            else gameObjects[i].transform.position = new Vector3(transform.position.x, -0.5f + i, 0);
        }
    }
}
