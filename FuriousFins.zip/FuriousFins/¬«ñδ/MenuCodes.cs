using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuCodes : MonoBehaviour
{
    public Text txt;
    public Text texts;
    public static int HighScore = 0;
    void Start()
    {
        if (HighScore < CounterPoints.points)
        {
            txt.text = "High-Score: " + CounterPoints.points;
            HighScore= CounterPoints.points;
        }
        else txt.text = "High-Score: " + HighScore;
        texts.text = "Last-Score: " + CounterPoints.points;
    }
    public void StartGame()
    {
        SceneManager.LoadScene("SampleScene");
    }
}
