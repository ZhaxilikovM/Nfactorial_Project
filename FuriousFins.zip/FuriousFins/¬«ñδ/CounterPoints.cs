using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CounterPoints : MonoBehaviour
{
    public static int points;
    public Text txt;
    void Start()
    {
        points = 0;
    }

    // Update is called once per frame
    void Update()
    {
        string texts = "Score: " + points;
        txt.text = texts;
    }
}
