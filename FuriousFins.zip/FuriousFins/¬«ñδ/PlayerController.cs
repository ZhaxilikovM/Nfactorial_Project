using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private Rigidbody2D rb;
    private SpriteRenderer render;
    public Sprite[] sp;
    public static int speed = 1;
    public int jumpforce = 5;
    private float startedTime = 0.5f;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        render = rb.GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        if (startedTime >0)
        {
            startedTime-= Time.deltaTime;
            rb.Sleep();
        }
        else
        {
            rb.WakeUp();
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            rb.velocity = new Vector3 (0, jumpforce, 0);
            AudioSource audioSource = GetComponent<AudioSource>();
            audioSource.Play();
        }
        if (rb.velocity.y > 0)
        {
            transform.rotation = Quaternion.Euler(0f, 0f, 10f);
            render.sprite = sp[0];
        }
        else
        {
            transform.rotation = Quaternion.Euler(0, 0f, -10f);
            render.sprite = sp[1];
        }
    }
}
