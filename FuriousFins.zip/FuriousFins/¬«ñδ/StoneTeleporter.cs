using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoneTeleporter : MonoBehaviour
{
    void Update()
    {
        
        transform.Translate(Vector3.left*Time.deltaTime*InterGame.speedgame);
        if (transform.position.x <= -13.73)
        {
            transform.position = new Vector3(15.58f,transform.position.y,1);
        }
    }
}
